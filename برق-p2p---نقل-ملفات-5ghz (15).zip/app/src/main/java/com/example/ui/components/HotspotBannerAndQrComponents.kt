package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FileCategory
import com.example.model.HotspotNetworkStatus
import com.example.ui.theme.CoralRose
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightCardElevated
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.util.QrCodeGenerator
import java.util.Locale

@Composable
fun CopyrightFooter(
    modifier: Modifier = Modifier
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .fillMaxWidth()
            .background(MidnightSurface)
            .border(width = 0.5.dp, color = GlassBorder)
            .padding(vertical = 8.dp, horizontal = 16.dp)
            .testTag("copyright_footer")
    ) {
        Text(
            text = "جميع الحقوق محفوظة © saeed",
            style = MaterialTheme.typography.labelLarge,
            color = ElectricCyan,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Floating selection summary bar shown whenever the user selects 1+ apps or files
 * in any manager screen (Apps, Images, Videos, Audio, Files).
 */
@Composable
fun SelectionBottomActionBar(
    selectedCount: Int,
    selectedBytes: Long,
    onClearSelection: () -> Unit,
    onAddSelectedToSendQueue: () -> Unit,
    selectedFoldersCount: Int = 0,
    selectedFilesCount: Int = 0,
    isSessionActive: Boolean = false,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = selectedCount > 0,
        enter = slideInVertically { it },
        exit = slideOutVertically { it }
    ) {
        val breakdownText = when {
            selectedFoldersCount > 0 && selectedFilesCount > 0 ->
                "تم تحديد $selectedCount عنصر ($selectedFoldersCount مجلد + $selectedFilesCount ملف)"
            selectedFoldersCount > 0 ->
                "تم تحديد $selectedFoldersCount مجلد كامل"
            else ->
                "تم تحديد $selectedCount عنصر"
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(MidnightCardElevated)
                .border(1.5.dp, NeonEmerald, RoundedCornerShape(18.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .testTag("selection_bottom_action_bar")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onClearSelection,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(CoralRose.copy(alpha = 0.18f))
                        .testTag("clear_selection_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "إلغاء التحديد",
                        tint = CoralRose,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = breakdownText,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.testTag("selection_counter_label")
                    )
                    Text(
                        text = "الحجم الإجمالي: ${formatBytesArabic(selectedBytes)}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        color = ElectricCyan,
                        modifier = Modifier.testTag("selection_total_bytes_label")
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onAddSelectedToSendQueue,
                colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("send_selected_items_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Send,
                    contentDescription = null,
                    tint = Color(0xFF002418),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isSessionActive) "إضافة للجلسة ($selectedCount)" else "إرسال ($selectedCount)",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFF002418),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Network-agnostic instructional banner explaining flexible connectivity
 * across Wi-Fi (2.4GHz / 5GHz), Hotspot without internet, or any shared network (3G/4G/5G/LAN).
 */
@Composable
fun Hotspot5GHzInstructionBanner(
    networkStatus: HotspotNetworkStatus,
    onShowDetailsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hotspot_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF2B1E0B),
                        Color(0xFF0E1D34),
                        Color(0xFF092230)
                    )
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        HotspotAmber.copy(alpha = 0.85f),
                        ElectricCyan.copy(alpha = 0.65f)
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .clickable { onShowDetailsClick() }
            .padding(16.dp)
            .testTag("hotspot_instruction_banner")
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(HotspotAmber.copy(alpha = 0.18f))
                            .border(1.dp, HotspotAmber.copy(alpha = pulseAlpha), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.WifiTethering,
                            contentDescription = "اتصال مرن",
                            tint = HotspotAmber,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "اتصال مرن على كافة الشبكات",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = HotspotAmber,
                                shape = RoundedCornerShape(999.dp)
                            ) {
                                Text(
                                    text = "2.4G / 5G / Hotspot",
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = Color(0xFF1F1200),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "الحالة الحالية: ${networkStatus.networkTypeLabel}",
                            style = MaterialTheme.typography.labelMedium,
                            color = ElectricCyan
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Filled.Info,
                    contentDescription = "تفاصيل الاتصال",
                    tint = HotspotAmber,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "يعمل النقل المباشر عبر أي شبكة Wi-Fi (سواء 2.4GHz أو 5GHz) أو نقطة اتصال محلية بدون إنترنت، كما يتكيف تلقائياً مع سرعة الشبكة أياً كان جيل الاتصال (3G / 4G / 5G).",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFE2E8F0)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(NeonEmerald)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "العنوان: ${networkStatus.localIp}:${networkStatus.port}",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        color = NeonEmerald
                    )
                }

                Text(
                    text = "دليل الربط بين هاتفين ←",
                    style = MaterialTheme.typography.labelMedium,
                    color = HotspotAmber,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun QrCodeCanvas(
    content: String,
    size: Dp = 210.dp,
    modifier: Modifier = Modifier
) {
    val matrix = remember(content) {
        QrCodeGenerator.encodeToMatrix(content)
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White)
            .border(3.dp, ElectricCyan.copy(alpha = 0.7f), RoundedCornerShape(22.dp))
            .padding(14.dp)
            .testTag("qr_code_canvas")
    ) {
        Canvas(modifier = Modifier.size(size - 28.dp)) {
            val moduleCount = matrix.size
            if (moduleCount == 0) return@Canvas
            val cellSize = this.size.width / moduleCount.toFloat()

            for (r in 0 until moduleCount) {
                for (c in 0 until moduleCount) {
                    if (matrix[r][c]) {
                        val isFinderCorner =
                            (r < 7 && c < 7) ||
                                (r < 7 && c >= moduleCount - 7) ||
                                (r >= moduleCount - 7 && c < 7)
                        drawRoundRect(
                            color = if (isFinderCorner) Color(0xFF06152D) else Color(0xFF0A192F),
                            topLeft = Offset(c * cellSize, r * cellSize),
                            size = Size(cellSize * 1.03f, cellSize * 1.03f),
                            cornerRadius = CornerRadius(cellSize * 0.2f, cellSize * 0.2f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun P2PRadarWaveIllustration(
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "radar_wave")
    val waveProgress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_progress"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(84.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MidnightCard)
            .border(1.dp, GlassBorder, RoundedCornerShape(18.dp))
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val cy = size.height / 2f
            val rightX = size.width * 0.82f
            val leftX = size.width * 0.18f

            drawLine(
                brush = Brush.horizontalGradient(
                    colors = listOf(NeonEmerald.copy(alpha = 0.4f), ElectricCyan.copy(alpha = 0.4f))
                ),
                start = Offset(leftX, cy),
                end = Offset(rightX, cy),
                strokeWidth = 4.dp.toPx()
            )

            for (i in 0..3) {
                val p = ((waveProgress + i * 0.25f) % 1f)
                val packetX = rightX - (rightX - leftX) * p
                drawCircle(
                    color = if (i % 2 == 0) ElectricCyan else NeonEmerald,
                    radius = 5.dp.toPx(),
                    center = Offset(packetX, cy)
                )
            }

            val maxRadius = 30.dp.toPx()
            drawCircle(
                color = ElectricCyan.copy(alpha = (1f - waveProgress) * 0.45f),
                radius = maxRadius * waveProgress,
                center = Offset(rightX, cy),
                style = Stroke(width = 2.dp.toPx())
            )
            drawCircle(
                color = NeonEmerald.copy(alpha = (1f - waveProgress) * 0.45f),
                radius = maxRadius * waveProgress,
                center = Offset(leftX, cy),
                style = Stroke(width = 2.dp.toPx())
            )

            drawCircle(color = ElectricCyan, radius = 8.dp.toPx(), center = Offset(rightX, cy))
            drawCircle(color = NeonEmerald, radius = 8.dp.toPx(), center = Offset(leftX, cy))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Text(
                text = "الهاتف المرسل (P2P)",
                style = MaterialTheme.typography.labelMedium,
                color = ElectricCyan,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "برق sher • SHA-256",
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 11.sp,
                color = TextSecondary
            )
            Text(
                text = "الهاتف المستلم (P2P)",
                style = MaterialTheme.typography.labelMedium,
                color = NeonEmerald,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

fun categoryIcon(category: FileCategory): ImageVector = when (category) {
    FileCategory.VIDEO -> Icons.Filled.Movie
    FileCategory.IMAGE -> Icons.Filled.Image
    FileCategory.AUDIO -> Icons.Filled.MusicNote
    FileCategory.GAME_APK -> Icons.Filled.Android
    FileCategory.ARCHIVE -> Icons.Filled.FolderZip
    FileCategory.DOCUMENT -> Icons.Filled.Description
    FileCategory.FOLDER -> Icons.Filled.Folder
}

fun formatBytesArabic(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val gb = 1024.0 * 1024.0 * 1024.0
    val mb = 1024.0 * 1024.0
    val kb = 1024.0
    return when {
        bytes >= gb -> String.format(Locale.US, "%.2f GB", bytes / gb)
        bytes >= mb -> String.format(Locale.US, "%.2f MB", bytes / mb)
        bytes >= kb -> String.format(Locale.US, "%.1f KB", bytes / kb)
        else -> "$bytes B"
    }
}

fun formatSpeedArabic(bytesPerSec: Double): String {
    if (bytesPerSec <= 0.0) return "0.0 MB/s"
    val mib = 1024.0 * 1024.0
    val mbDecimal = 1_000_000.0
    val kb = 1024.0
    return when {
        bytesPerSec >= mib -> String.format(
            Locale.US,
            "%.2f MB/s (%.2f MiB/s)",
            bytesPerSec / mbDecimal,
            bytesPerSec / mib
        )
        bytesPerSec >= 100 * kb -> String.format(Locale.US, "%.2f MB/s", bytesPerSec / mbDecimal)
        else -> String.format(Locale.US, "%.1f KB/s", bytesPerSec / kb)
    }
}

fun formatDurationArabic(durationMillis: Long): String {
    if (durationMillis <= 0L) return ""
    val totalSec = durationMillis / 1000L
    val hours = totalSec / 3600L
    val minutes = (totalSec % 3600L) / 60L
    val seconds = totalSec % 60L
    return if (hours > 0) {
        String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }
}
